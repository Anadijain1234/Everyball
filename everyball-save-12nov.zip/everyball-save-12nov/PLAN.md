# Everyball: plan and progress

> **For any new chat with Claude:** read this file first, all of it (and docs/ESPN_LIVE_SURVEY.md before ESPN work). **Before building, read docs/BUILD_SPEC.md: the complete build specification (every source, table, rule, check and step).** It says what is decided, what is done, what is
> still missing and the exact next step. Anadi also keeps the key decisions in Claude's memory. If something here and
> a chat disagree, ask Anadi; then fix this file. Update this file at the end of every working session.

## What we are building
A cricket history site: **every Test since 1877, every ODI since 1971**, ball by ball wherever it exists.
- Ask in plain words (English + Hindi) and get exact numbers, with a "how it was counted" line. The AI only turns the question into a database query; **the database does the counting** and never invents numbers.
- **Legendary Duels**: the great batter vs the great bowler of each era, ball by ball, with a coverage meter and a "who won" verdict.
- Player pages, top lists, "same age" comparisons (Gill at 27 vs Gavaskar at 27), eras.
- **Every ball's commentary** where ESPNcricinfo has it: every commentator line, the text between balls (insights,
  quotes, interviews), over summaries, line / length / shot type / scoring zone. Shown with "Commentary: ESPNcricinfo"
  next to it (ESPN's condition).
- **Fall of wickets and partnerships** for every innings (exact from the balls where we have them; from the printed
  scorecards where we don't).
- **"Which player struggles where"**: by line, length, bowling type, ground, country (SENA etc.), era.
- **A model on top of the data** (Stage 3-4): estimates for what doesn't exist anywhere, always shown as estimates.
- Men's Tests and ODIs only. **No T20s** (Anadi, 13 Nov: not the real format for him; integrating it is a headache; Tests + ODIs are already huge).
- **Stat ideas agreed (11-12 Nov):** pressure meter (chance of getting out after 3-5 dots in a row), first 10 balls vs
  set, new vs old ball, powerplay / middle / death, batting first vs chasing, home vs away, year by year, bunny finder
  (with a luck check), 10x10 batter-v-bowler heatmap, how each player gets out (bowled/LBW/caught behind...), false-shot %
  (ESPN shotControl), pitch maps by length zone (ESPN line/length labels), DRS reviews, debutants.
- **Dravid v Steyn = the "expected vs actual" duel model (Stage 3):** every match gets a "conditions" number; start from
  "batter v everyone" + "bowler v everyone", move only when the real duel clearly differs (Bayesian, borrows strength);
  answer as a range ("Dravid won, 21-41"); tested on hidden modern matches.
- **Commentary labelling (Stage 3):** Qwen labels 5,000 lines, a small model learns the rest; Anadi hand-labels 500
  lines to measure accuracy; a keyword method is the baseline to beat. The model learns from ALL text, not only ball lines.
- **Later:** ESPN match reports for pitch tags (not downloaded yet); Ranji (adjusted stats, Ranji form -> Test form,
  "ready for India" list).
- **Honest limits (never promise):** no ball speed or swing data, no Hawk-Eye pitch maps in metres, no 3D simulation.

## Rules (Anadi's, never break them)
- **Build only when Anadi says "build".** Explain the plan and answer questions first. Plain, simple language.
  Terminal commands bundled into a few copy-paste blocks (chained with &&). No Codespaces Ports/localhost preview:
  deploy straight to Render.
- **Every piece of data that exists should be caught.** No subsets. Keep the "still missing" list below up to date and
  fill it even if Anadi forgets to remind.
- **Nothing is dropped silently.** Raw files are never changed or deleted; every field of every source has a written
  decision (which table/column, or "raw only" with a reason); every reader counts what went in and what came out.
- **Never present made-up data as real.** Model estimates live in their own clearly labelled place, with ranges.
- **Respect every source's limits and conditions**: Davis up to 300 requests/min; ESPNcricinfo up to 5,000/min (raised
  from 1,000 in Nov 2026), credit ESPN and send them the site link once it's live; the Wisden book: numbers only.
- **Keys** (Groq, Sarvam, GitHub, Hindsight) never on GitHub and never pasted in chat: Render env, GitHub secrets or
  `.env` (gitignored) only. Anadi never pastes GITHUB_TOKEN. Never push to the Hindsight repo. **Claude never pushes, commits or changes anything on GitHub** (Anadi, 13 Nov): it may only read/download (e.g. the raw-data release) when access is given; Anadi commits and pushes himself. Never write "hackathon"
  in public content. Raw data (`data/raw/`) never in GitHub history.

## Data sources (all with permission)
| Source | What we take | Years | Permission / credit |
|---|---|---|---|
| **Charles Davis**, Test Match Database (sportstats.com.au) | Test ball-by-ball (about 82% of all Tests) + Test scorecards | 1877 to 2010s | Permission by email (Anadi). Raw files may be shared too. Credit on the Credits page. |
| **Cricsheet** (cricsheet.org) | Test + ODI ball-by-ball | about 2002 to now | Free (ODC-BY): credit |
| **ESPNcricinfo old archive** (i.imgci.com) | ODI/Test ball-by-ball commentary + "player v player" files; old scorecards (who took each wicket) | Oct 1998 to 2002; scorecards 1970-71 on | Permission by email (Anadi), with credit |
| **ESPNcricinfo live site** (www.cricinfo.com, its commentary feed) | The **whole** commentary of every Test and ODI that has it, every item untrimmed; PLUS for every one of 7,692 matches since 1877: ESPN's scorecard (fall of wickets, partnerships, over-by-over, DRS), match facts, and every player (date of birth, batting/bowling style, role) | as far back as ESPN has it (some recreated: RetroLive 2020) | Permission by email (Anadi): up to 5,000 requests/min, credit + send them the site link |
| **The Wisden Book of Test Cricket, Vol. 1** (bought copy) | Numbers only (scorecards, results), cross-checked against Davis | 1877-1970 | Never its pages, layout or text; credit |
| **Kaggle ODI dataset** (bhuvaneshprasad) | ODI scorecards, balls faced, partnerships, fall of wickets; players' bowling style + date of birth | 1971 to Mar 2024 | Credit the uploader (TODO: note its licence from the Kaggle page) |
| Our own lists | nicknames, ground to country (SENA, home/away) | | ours |

Not used: CricketArchive (paid, scorecards only). Cricmetric (no API). Usenet rec.sport.cricket 1991-97 (fans'
over-by-over posts, patchy, manual only). ACS scorebooks (paper). Rob Moody's videos (footage, not data).
Kaggle "subhrajyotinath" ODI ball-by-ball (probably Cricsheet-based; not checked). "Milan Foundation": nothing found.

**Priority when sources overlap:** Cricsheet, then Davis, then the ESPN files, then scorecards. Every match's balls must add up to its scorecard, or the match is flagged.

**Credits:** one Credits page only (in the menu). No footer credits.

## Coverage (12 Nov 2026 night; ESPN's own lists: 2,643 Tests, 5,061 ODIs)
Ball-by-ball, all sources together (our database + ESPN full commentary + redo):

| Decade | Tests | ODIs |
|---|---|---|
| before 1970 | 489 / 669 | - |
| 1970s | 139 / 198 | 0 / 82 |
| 1980s | 203 / 266 | 0 / 516 |
| 1990s | 312 / 347 | 130 / 933 |
| 2000s | 462 / 464 | 1,320 / 1,405 |
| 2010s | 433 / 433 | 1,284 / 1,287 (3 = washouts) |
| 2020s | 266 / 266 | 835 / 838 |
| **Total** | **2,304 (87.2%)** | **3,569 (70.5%)** |

- ESPN added 16 Tests + 486 ODIs that had no ball-by-ball before (incl. ODIs #1722, #1724 from the redo).
- Scorecards: ESPN has one for every match except 8 ODIs; plus Davis, Kaggle, the book.
- Not available anywhere digital: ODI ball-by-ball before Oct 1998 (paper only), most pre-2000 Tests without Davis.
- ESPN labels: shot type + shot control ~85-90% of balls from 2000; line & length ~90% from 2015 (13% 2010-14,
  none before); wagon wheel real mostly recent (0 = not recorded); timestamps 2020+; text on 12% of balls in 2000-04,
  62% 1990s, 80% 2005-09, 96%+ from 2010.

## Stages
1. **Data foundation**: downloader, readers, one database, cross-checks, coverage counts.
2. **The site**: Ask, Legendary Duels, players, top lists, Credits, coverage meter. Render free plan + a pinger
   (UptimeRobot / cron-job.org) so it never sleeps. Then **2b: the weekly robot** (see "Automation").
3. **Context model**: pitch/spin/seam indices from match numbers, pitch tags from match reports, pressure, matchup
   ("expected vs actual") verdicts with ranges.
4. **Research + the model** (trained on Kaggle, see "The model"): estimate head-to-heads for matches without
   ball-by-ball from scorecards (IPF, Bayesian/MCMC, Markov + multinomial), tested on hidden modern matches; paper with
   a professor.

## The model (Anadi's vision, 12 Nov 2026)
Trained on Kaggle (free GPU) on everything we have. What it should do:
- **Line / length / shot for older balls**: learn from 2015+ balls (ESPN recorded both the words and the labels), then
  read the 2001-2014 commentary text ("full and wide outside off, driven") and fill those in. ~1 million more balls.
- **Head-to-heads where no ball-by-ball exists** (e.g. Gavaskar v Imran, Border v Hadlee): use each player's style from
  all their real data plus the hard facts of each match (scorecard, who got out to whom, fall of wickets, partnerships,
  when each batter got out) to estimate e.g. "about 180-230 runs off Imran". Dismissals by bowler are real (scorecards).
- **Predict** line/length tendencies and matchups; **which player struggles where**; later **scout domestic players**
  (needs domestic data).
- **Retrains itself**: the weekly robot adds new labelled balls; a monthly Kaggle run (Kaggle API) trains a new
  version; it replaces the old one **only if it scores better on a fixed hidden test set**; then it re-labels the old
  balls.
- **Always labelled "estimate"** (with a range), never mixed silently with real data. Accuracy shown. This is the
  research paper.
- Not a model job: exact stats (Sachin's runs at the Basin Reserve, SENA splits, fall of wickets). The Ask box answers
  those from the database (Groq writes the query, Sarvam for Hindi); nothing to train, new matches show up at once.

## Automation (Stage 2b)
- **Cricsheet**: GitHub Actions robot, weekly: download new matches, build, run the famous-facts checks, pack, push.
  Render redeploys by itself.
- **ESPN**: GitHub's servers are data-centre computers, which ESPN refuses (the Codespace got 403). So the ESPN job
  runs on Anadi's laptop as a **self-hosted runner**: a hidden browser opens cricinfo.com, borrows Cricinfo's own pass
  maker (see "ESPN commentary feed"), downloads the week's new matches, builds and pushes. Runs whenever the laptop is
  on. (First: a 1-minute test of whether ESPN refuses a GitHub robot; and confirm with ESPN that a small weekly
  automatic update is covered.)
- The robot emails only when something fails (ESPN moved the pass maker, Cricsheet changed format, a new name doesn't
  match).

## ESPN commentary feed: how it works (learned 12 Nov 2026)
- Feed: `https://hs-consumer-api.cricinfo.com/v1/pages/match/comments?lang=en&seriesId=..&matchId=..&inningNumber=N`
  `&commentType=ALL&sortDirection=DESC[&fromInningOver=X]`; ~3 overs per answer; next page from `nextInningOver`.
- Every call needs header `x-hsci-auth-token: exp=..~hmac=..`, made from that exact path by Cricinfo's own code
  (webpack item 764, export `L`, module `akamai_hmac`) and valid 60 s. Our browser scripts borrow that function
  through `self.webpackChunk_N_E` (and search for it if the number changes). Without it: 403.
- Match pages: `/ci/engine/match/<ESPN id>.html` -> `__NEXT_DATA__` (match, hasCommentary, series.objectId,
  innings with players).
- Items keep fields like `commentTextItems`, `commentPreTextItems`, `commentPostTextItems`, `commentImages`, ball
  fields (overNumber, ballNumber, oversActual, runs, extras, isWicket, dismissalType, batsmanPlayerId,
  bowlerPlayerId, pitchLine, pitchLength, shotType, shotControl, wagonZone...). The reader must be written from a
  **survey of all files** (every field, every item type, counts by year), not from samples.
- Speed: speed = doors x (60 / seconds per request), capped by the smallest of: our limit, the line, Chrome (~100 at
  once to one site), the laptop (keep the tab **visible** and RAM free: Chrome slows hidden tabs). 80 doors for 5,000/min.

## Layers (medallion)
- **Bronze**: raw downloads in `data/raw/`, never changed.
- **Silver**: every source read into the same tables, each row tagged with its `source` (davis, cricsheet, espn,
  kaggle, book), plus `played` (every player in each XI) and `ref_matches` (ESPN's own year lists).
- **Gold**: one chosen version per match (`matches.card_source` / `ball_source`: a source that adds up, by priority),
  the views `bat`, `bowl`, `ball`, `inns`, one record per person (`people` step), and `player_stats`.
  The website and the Ask box read only gold.

## Storage
- Raw downloads: `data/raw/` in the Codespace (gitignored, never in the code history).
- **Safe copy of the raw downloads: automatic, every 20 min, to this private repo's Releases -> `raw-data`**
  (`scripts/backup.py`). A stopped Codespace loses nothing; a deleted one is restored by `bash scripts/start.sh`.
  Laptop copy: `python scripts/backup.py laptop` when everything is done, then one click on the Releases page.
- **Growth is small:** ~150-200 new Tests/ODIs a year = ~30 MB of new raw files and ~20 MB of new commentary text a
  year. Releases are enough (no limit on total size; 2 GB per file; new raw files added as weekly/monthly assets).
  No hosted database (Neon etc.) needed: their free tiers are smaller than our database, and a database file the site
  downloads at deploy is free and fast.
- Finished database: today in the repo (data/web, 773 MB -> 95 MB xz). **Move it to a Release** before the weekly robot,
  or every update adds ~100 MB to the code history. Render's build downloads it from the Release (token in Render env).
- Expected size with all commentary: ~1.5-2 GB plain (text ~0.4 GB + search index). Render free: 512 MB RAM (fine,
  SQLite reads from disk), 0.1 CPU (so heavy counting is done at build time), disk size not published -> test it.
  Plan B: commentary in a private Hugging Face dataset (100 GB free), fetched per match when opened.
- Render (the website, later) stores nothing: its free disk is wiped on every restart. It reads the finished
  database that comes with the code from GitHub.
- Keys (later): `.env` only, never on GitHub.

## Progress
- [x] **Step 1**: private repo `Everyball`, Codespace, folders, .gitignore (Anadi, 11 Nov 2026)
- [x] **Step 2**: downloader `scripts/download.py` + tests (Claude, 11 Nov 2026)
- [x] Step 2b: live tracker `scripts/tracker.py` (+ phone page), progress files, retry of failed files (Claude, 11 Nov 2026)
- [x] Step 2c: automatic backup to GitHub Releases (`scripts/backup.py`) + one-command start/resume (`scripts/start.sh`) (Claude, 11 Nov 2026)
- [x] Step 2d: Davis dead links handled fast (asked once, listed, never retried), pause 0.75 s, automatic slow-down on refusals, folder-typo and capital-letter fixes; ESPN one-year folders (`espn-years`), ESPN pause 1 s; tracker in India time with dead links shown (Claude, 11 Nov 2026)
- [x] **Step 3**: run the downloader in the Codespace (Anadi): `bash scripts/start.sh`. Started 11 Nov 2026: Cricsheet + Kaggle done; Davis found 24 archive links in contents.pdf, then about 11,400 PDFs in all (about 9-10 hours at 1.5 s each); ESPN ball-by-ball about 480+ files. Then `python scripts/download.py retry` and `python scripts/backup.py now`.
- [x] **Step 3**: everything downloaded and backed up (68,229 files; Davis 10,719 files, ESPN about 7,000, Cricsheet, Kaggle) (11 Nov 2026)
- [x] **Step 4**: samples studied (11 Nov 2026)
- [x] **Step 5, part 1 (Tests)**: `scripts/build_db.py` + readers for Davis (Test pages, ball-by-ball with batter-by-batter checks, covers, player lists), Cricsheet, the Wisden book data; `scripts/checks.py` (ESPN year lists, Test-number gaps, cricket maths, Davis vs Cricsheet/book, famous facts); `scripts/ask.py` (Claude, 11 Nov 2026)
- [x] **Step 5, part 2 (ODIs)**: `read_kaggle.py` (every ODI 1971-2024, numbered; players joined to Davis/Cricsheet names by cricinfo id, full name, then surname + first name/initial) and `read_espn.py` (scorecards used only when every innings adds up; ball-by-ball commentary + the commentary text; player-v-player tables); report checks ESPN commentary against ESPN's player-v-player tables (Claude, 11 Nov 2026)
- [x] **Stage 2a: the website** (Claude, 12 Nov 2026): Flask (`app/`), Duel finder with autocomplete and the
  "every ball" strip, player pages (totals, year by year, how he got out, rivals), coverage by decade, Credits page,
  light/dark, phone layout. Ask box: Groq `openai/gpt-oss-120b` writes one read-only SQL query; the database counts;
  the answer line is written from the returned rows only; "How it was counted" shows the query. Hindi via Sarvam
  (`mayura:v1`). 6 questions/min and 60/day per visitor; same question = cached answer. `scripts/publish_db.py`
  packs the database into 45 MB parts for GitHub; `render.yaml` for Render.
- [x] **Step 5, round 3: the full data, fixed in one go** (Claude, 12 Nov 2026, on Anadi's full data): Davis's newer
  pages (mixed-case teams), batter lines read by dismissal words (one-space gaps, wrapped lines, '#N/A', daggers,
  5 penalty runs), wrong team names in Davis's templates, "Scores of 50+" pages skipped, Davis's short names in the
  ball-by-ball ('M Jayaward.', 'Javed M.', 'G Pollock'), partial old records marked; every source's match number
  checked against ESPN's year lists; the book's OCR numbers checked by date and teams; one person = one record
  (ESPNcricinfo ids + name matching); every player in the XI counted (did not bat); a scorecard is only chosen if
  its batters and bowlers add up. Result: all 9 famous facts PASS; Davis scorecards add up 99.4%; Davis vs Cricsheet
  22,052/22,054 batters agree; Davis ball-by-ball: 98.6% of balls proven, 94.1% of batters match the scorecard.
- [ ] Anadi: run the one command (unzip, tests, commit, build), then try the site in the Codespace; pack + Render.
- [ ] Later: recent matches Cricsheet doesn't have yet (19 Tests, 32 ODIs, mostly 2024-26) -> fresh Cricsheet download
  (Stage 2b weekly update); ESPN commentary vs player-v-player (612/905 innings agree) to look at.
- [ ] **Step 6**: build the database (Anadi): `python scripts/build_db.py all`, then send Claude data/build_report.txt
- [ ] Stage 2b (later): weekly Cricsheet update with GitHub Actions + Render auto-deploy
- [ ] Anadi's side task: 100 test questions with correct answers from ESPN (Tests + ODIs, old + new)
- [x] **12 Nov 2026: catching what's missing.** Browser check of ESPN's site for all 2,333 matches without our
  ball-by-ball: 515 have commentary (40 old ODIs: RetroLive recreations + Cricinfo's own 1999-2002 live text; 0 old
  Tests). `everyball_espn_commentary.js` (trimmed fields) downloaded 502 of them: 320 add up exactly, 109 within 1-5
  runs, 28 with gaps, 45 brand-new 2024-26 matches. 13 came back empty. Davis dead-link recheck: 0 found so far.
- [x] **12 Nov 2026: the WHOLE ESPN commentary downloaded** (`everyball_espn_full_commentary.js`, 80 doors, up to
  5,000/min): 66 files `espn_full_commentary_part001..063.json.gz` (+ three "(1)" copies made by a resume; their 240
  records are exact duplicates), 700 MB zipped, 11.7 GB raw. 7,692 matches: 4,517 with commentary, 3,175 none.
  Kept on Anadi's laptop: Downloads\ESPN full commentary\. **The script itself is NOT in the repo yet: copy it into
  scripts/browser/.**
- [x] **12 Nov: survey of every file and every item** (`scripts/tools/survey_espn_live.py`): see docs/ESPN_LIVE_SURVEY.md.
- [x] **12 Nov: redo of 20 matches** (`scripts/browser/everyball_espn_redo.js`, ids checked against ESPN's numbers):
  the 12 the full run missed (Tests #1548-1549, ODIs #1720-1729) + 8 played ODIs that came back empty. Result
  `espn_full_commentary_redo.json.gz` (1.3 MB): 12 with commentary (9,451 items), 8 still empty (ESPN never wrote any;
  scorecards + players kept). Runs add up in 31/32 innings, legal balls in 29/32.
- [x] 12 Nov: Davis dead links re-checked: really dead. Closed.
- [x] 12 Nov: repo zip reviewed. Repo had an older PLAN.md (this file replaces it).

## Data verdicts (12 Nov 2026: audit of the three "Database inspiration" zips + the ESPN survey)
Rule: "remove" = not in the database; it still stays in the raw files forever. Nothing is deleted.

**Raw data we have but the database does NOT use yet (must be added):**
- Book `fall_of_wickets.csv` (20,746 rows, 1877-1970), `debuts.csv` (1,212), `appearances.csv` (14,805: every XI),
  `players.csv` (1,428: first/last Test). Only matches/innings/batting/bowling are read today.
- **Davis (full archive checked 13 Nov: 10,719 files, 1.29 GB).** Read today: Test pages (3,084), ball-by-ball
  (2,008), series covers (~742). **Never read:** fall-of-wickets PDFs (2,020), session-by-session PDFs (~742), series
  averages (~742), Davis's notes ("text", 80), series/era lists and index PDFs (~740, e.g. "10.pdf"), series web
  pages (553), specials (1893field, 1975WI3time, hanif337, "A Note on Score Reconstruction"). Read them all (credit).
- ESPN `_index` (50,496 pages, 1.44 GB): the downloader's folder/navigation pages, incl. domestic matches, squads and
  picture pages. Raw only, except squads/tour pages if they add players we lack (check once).
- Kaggle `odi_Fow_Card.csv` (67,963 rows) + `odi_Partnership_Card.csv` (73,826 rows): never read today.
- ESPN old archive: **1,226 match reports (MR)**, 573 run-rate comparisons (over-by-over, 1990s-2002),
  224 wagon-wheel pages (scoring zones 1999-2002), 527 graph pages and 25 BBB pages (check what they add).
- Cricsheet: DRS reviews (`review`), concussion/other replacements, player of the match, absent hurt,
  miscounted overs.
- ESPN live: everything (balls, labels, all text, scorecards with fall of wickets/partnerships/overs/DRS, players).

**GOLD (keep and use, no choice):** every ball's facts from every source (every version, disagreements kept);
every piece of commentary text (ball lines, before/after text incl. lunch chatter and interviews, over summaries,
dismissal text, old BBB-COMMS lines, match reports); every scorecard from every source; fall of wickets and
partnerships from every source; ESPN labels (line, length, shot, shot control, real wagon wheel, dismissal type);
players (date of birth, styles, role, country, death date, every name form, every id); match facts (toss, result,
ground, umpires, referee, player of the match, debutants, replacements, DRS, absent hurt).

**KEEP (useful, lower value; in the archive, used when needed):** over-by-over (ESPN live `inningOvers`, old
RR-COMPARISON), minutes batted, ball timestamps (2020+, for sessions), hours/day-night/series/commentator/scorer
names, ESPN's win `predictions` (2020+; ESPN's own model, always labelled "ESPN estimate", never mixed with facts),
tweets/polls embedded in commentary (their text + link), old GRAPH pages (only if they hold numbers we lack).

**REMOVE from the database (raw files only):** player/team images, captions, credits, sizes, logos, colours; old
AUDIO/PICTURES/IMAGES/SLIDESHOW pages; video metadata (playback links, expiry, genre, country codes), live-stream
and ad/iframe/Playbuzz/Instagram/Facebook embeds; site internals (slugs, scribe ids, page flags like hasGalleries,
fantasy story ids, languages, "modified" times); the 240 duplicate ESPN records.

**For the model:** all text is used, but every piece keeps its kind (ball line / before / after / over summary /
report), so the line-length-shot labeller learns from ball lines while insights, pitch and weather talk feed the
"conditions" and duel (Dravid v Steyn) models. **Promo vs gold: decided from the real data (12 Nov, every one of the 831,497 between-ball pieces checked)**
- The most repeated between-ball lines are GOLD, not promo: "Around the wicket" (635 matches), "Two slips and a
  gully", "Drinks", "Last over before lunch", "Free hit". They give bowling angle and field changes for the next balls.
  So "repeated = promo" is wrong and is NOT used.
- Promo is tiny and mostly one-off: only 4,637 pieces (0.56%) even contain promo words, and many of those are gold
  ("if Warner and Starc click..."). Word rules alone would delete gold, so they are NOT used either.
- 13,710 pieces talk line/length/what to bowl (the "yahan tappa pakdo" insights): always kept.
**Final rule (Claude's call, 12 Nov, after Anadi's push): nothing with words is ever deleted.**
1. Dropped: only empty shells with no words at all (video players, live-stream links, iframes, empty pieces).
   Polls and tweets keep their text.
2. Promo lines (~4,600 candidates, <1 MB) are NOT deleted: an AI judges each one and tags it "promo"; the site hides
   them and training skips them. Deleting them would save almost nothing and risk real cricket talk.
3. Every piece is kept and tagged by kind: ball line / before / after / over summary / dismissal / angle or field
   change / match state (drinks, lunch, tea) / reader comment ("Andy: ...") / tweet / poll.
4. Count check per match: raw pieces = stored + dropped shells, or the build stops.

## Cricket factors (labels) from the commentary and other sources (12 Nov, Anadi's "everything matters")
Every label keeps where it came from (ESPN field / exact text rule / AI with a confidence / measured weather) and
never overwrites the original. "Not mentioned" is stored as unknown, never as "no".
- **Delivery:** line, length (ESPN 2015+, AI from text before), pace/spin, variation (bouncer, yorker, slower ball,
  cutter, knuckle, googly, doosra, carrom, arm ball), movement (inswing, outswing, reverse, seam in/away, turn in/away),
  bounce (extra, low, uneven), speed when said ("142kph": exact rule).
- **Shot:** type and control (ESPN), front/back foot, direction (wagon), edges (inside/outside/top), beaten,
  left alone, mistimed, appeal, DRS and its outcome (umpire's call).
- **Field and angle:** over/around the wicket, slips and gully count, field changes (sweeper, leg-side field,
  packed off side), dropped catches, misfields, fielder positions named.
- **Conditions:** pitch (green, dry, cracks, turning, two-paced, flat, footmarks), weather (overcast, sunny, humid,
  rain, bad light), **dew**, **wind (direction and strength)**, ball (new, old, reverse, ball change), session,
  floodlights.
- **Tactics and pressure:** bowling plans (outside off, packed off side, short-ball plan, wide yorkers, leg theory),
  batting intent, dots in a row, required rate, partnership stage, injuries.
- **Measured weather (new source to add):** free historical weather archives (e.g. Open-Meteo, back to 1940) give
  temperature, humidity, wind speed/direction and rain for each ground and match day: measured (reanalysis) values,
  labelled as such, for matches with no commentary too.
- **Match reports** (ESPN old MR 1,226 + ESPN live report stories) add pitch and weather per match for older games.
- Exact rules (code) for: speeds, over/around the wicket, slip counts, drinks/lunch/tea, DRS outcomes. AI (labels
  a sample, a small model learns the rest, checked on Anadi's 500 hand-labelled lines) for meaning: pitch behaviour,
  movement, tactics, wind and dew talk.
- The model uses these as factors: e.g. "wind towards leg side + right-hander + leg-side boundary" -> the duel and
  conditions models learn what bowlers did and what worked.

**Training data (the model sees only clean, verified data; nothing is deleted to get it):**
- Balls: Cricsheet; Davis balls marked proven (98.6%); ESPN balls in innings that add up to the scorecard.
  Unproven or disagreeing balls stay in the database, flagged, and are left out of training.
- Labels: ESPN line/length (2015+, ~90%) and shot/control (2000+, ~85-90%) are the targets; ball lines are the input
  text; angle/field changes become features for the following balls; expert insights feed the conditions model;
  reader comments and promo candidates are not used for training.
- Scorecards, fall of wickets, partnerships (Davis, book, Kaggle, ESPN): the version that adds up, for the
  no-ball-by-ball estimates and the conditions number. Players: ESPN dates of birth and styles, checked with Kaggle.
- Every change to the training data is kept only if it scores better on the fixed hidden test set.

**How commentary is sorted (decided 12 Nov):** code, not an AI, stores and sorts every piece, because ESPN's own
fields already say which ball, which kind (ball line / before / after / over summary / dismissal) and which type
(HTML / tweet / poll / video): exact, nothing guessed, nothing dropped. A count check proves it: for every match,
pieces in the raw files = rows in the database, or the build stops and flags the match. An AI is used only where
meaning is needed (promo tags, and line/length/shot for older balls in Stage 3), and its answers go into **separate
label columns with a confidence**; it never edits or removes the original text. Reading all ~5 million pieces with an
AI (~100 million tokens) is too slow and costly, and an AI can silently drop or change words. 2000-04 has text on only 12% of balls.

## Next steps (resume here after the CIEs; Anadi, 12 Nov: do steps 3-7 as ONE build, not in stages)
0. **Release layout (all 18 parts checked 13 Nov; 68,229 files):** raw-data = part-0001..0018.zip (~1.45 GB; part 1 = Cricsheet + full Kaggle +
   part of Davis; the rest = Davis PDFs + ESPN old archive incl. its index pages). Copying all 18 from the laptop
   takes ~1 hour on PG WiFi, so for the build either link GitHub (read only) or copy them in one sitting.
0. **Before the build:** Anadi puts the original Kaggle zip (as downloaded from Kaggle) in
   `Downloads\Database inspiration\` next to the three for_claude zips. Also the FULL Davis folder (all ~10,700 files; the
   for_claude_davis zip has only 6,532 pages as text), packed in the Codespace into parts under 350 MB:
   `cd /workspaces/Everyball/data/raw && tar czf - davis | split -b 350m - /workspaces/Everyball/davis_raw.tgz.part_`
   (download each part, put them in the same folder, then delete them from the Codespace so they never reach GitHub).
   Cricsheet (full), ESPN old archive, ESPN year lists and the book CSVs are already in the for_claude zips. With those + the ESPN folder, Claude has
   every raw source and runs and tests the WHOLE build in its own workspace first (tests on known matches, every
   reader on every file, counts in = out, sums, source-vs-source, famous facts, then fix every flag and run again).
   Only then does the zip go to the Codespace for the real build.
1. **Commit this save zip** (PLAN.md, docs, scripts) + copy the full-commentary .js from the laptop into scripts/browser/.
2. **Get the 67 commentary files into the Codespace**: drag them onto the Releases page (`raw-data`), then
   `gh release download raw-data -p 'espn_full_commentary_*' -D data/raw/espn_full/`. (Release = permanent copy +
   backup; the laptop must not be the only copy.)
3. **Data audit ("field map")** (first pass done 12 Nov from the samples: see "Data verdicts"; Kaggle's extra CSVs still to list in the Codespace): for every source (Davis, Cricsheet, Kaggle, book, ESPN old, ESPN live) list every
   field in the raw files and where it lives in the database, or why it is raw-only. Known gaps already: Davis fall of
   wickets (parsed, not saved), Davis session pages, Kaggle FoW + partnership CSVs (not read), ESPN live (not read yet).
   Output: docs/FIELD_MAP.md + a "raw vs database" count report per source.
   **Small leftover found 13 Nov (the player-id joining works):** the real Glenn McGrath record holds all his
   51,426 balls and 915 bowling rows; but 3 stray name records remain: "W W GD McGrath" and "GD McGrath." (empty)
   and "McGrath" (30 Davis balls not joined). **The missing piece is match context:** the ESPN files give every
   match's XI with ESPN ids (7,692 matches, 1877 on). So every name from every source is joined by "which player of
   this team, in this match's XI, has this surname/initials", not by the name alone ("McGrath" bowling for Australia
   in a Test where Glenn McGrath is in the XI = him). Readers also clean names first (strip wicket marks "W W",
   trailing dots). After joining: empty records are removed; anything still unjoined is listed in the report, never
   guessed.
   Cross-check that worked: Sachin v McGrath ball by ball, ESPN vs our database, exact in 14 of 15 matches.
4. **ESPN live reader** (`read_espn_live.py`): balls (labels: line, length, shot, control, wagon, timestamp), every
   piece of text stored exactly as sent (HTML kept; a cleaned copy for search), kinds: ball line / before / after /
   over summary / dismissal; tweets, polls, videos as type + link. ESPN scorecards as a 4th scorecard source; players
   joined by ESPN ids (DOB, styles, roles). Balls lined up with Cricsheet/Davis (same over, ball, bowler, batter, runs);
   disagreements kept and flagged, never overwritten.
5. **New tables**: fall_of_wickets, partnerships, overs, drs_reviews, commentary (full), ball labels; from every source
   that has them (ESPN, Davis, Kaggle, book, computed from balls).
   Anadi asked (12 Nov): read **Kaggle's fall-of-wickets and partnership CSVs** and **save Davis's fall of wickets**
   (the Davis reader already parses it). Both raw sets are in the Release / Codespace.
6. **Two databases (proposed 12 Nov, confirm with Anadi):** (a) the **full archive** = every field of every source,
   every version where sources disagree, all text exactly as sent; lives in a Release (~2 GB plain, a few hundred MB
   packed), used for research, the model and rebuilds; (b) the **website database** = only what the site and the Ask
   box use (chosen scorecards and balls + labels, fall of wickets, partnerships, players, commentary), slim enough for
   Render. Raw-only items (image links, video metadata, ad embeds) stay in the raw files with a written reason.
7. Rebuild in the Codespace, checks + famous facts, measure size; DB to a Release; deploy to Render (+ pinger); send
   ESPN the link.
8. After the CIEs: Stage 2b robot (Cricsheet weekly; ESPN on a self-hosted runner), then the model.

## Still missing (keep this list current)
- Test #1541 (WI v SA, Mar 2001): no ball-by-ball anywhere yet.
- ESPN "commentary flag but nothing": 6 washed out after the toss (ODIs #5061, #4971, #4098, #3890, #3584, #2141:
  nothing to get) + 8 played with no commentary ever written (ODIs #2784, #2722, #2727, #2505, #2511, #2516, #2400,
  #1364): scorecards + players kept.
- 8 ODIs with no ESPN scorecard (other sources cover them; list them in the audit).
- The ESPN full-commentary browser script and the Kaggle licence note: not in the repo yet.
- ESPN match reports (pitch tags, Stage 3): not downloaded.
- Pre-2001 Tests/ODIs without ball-by-ball: only estimates possible (the model), never real.

### What we learned while downloading (11 Nov 2026)
- Davis's archive runs 1877 to **November 2020** (about 2,390 Tests), in **747 series**. Each series: cover, sessions,
  averages pages; each Test: main page, fall of wickets, ball-by-ball (looks like ONE bbb file per Test, for about 85%
  of Tests; to confirm on a sample). About 16,600 links in all, about 6,000 of them dead (empty Test slots on his pages).
- Real Davis files: about 10,000-11,000.
- ESPN's old archive: one-year folders (e.g. `ARCHIVE/2001/`) hold matches played in England; nothing before about
  the 1980s (`1970-71` is 404); blocked after about 2015-16 (`2020-21` gives 403).
- **Next check (after downloads):** count Davis's Tests per year and compare with ESPN's list of Tests per year
  (stats.cricinfo.com/ci/engine/records/team/match_results_year.html?class=1;id=YEAR;type=year, e.g. 1877 = Test #1, #2).
  Every year must match; any year that doesn't is looked at by hand. ODIs: compare ESPN files with the Kaggle ODI list.

### Step 4 sample files
1. `data/raw/davis/zArchive/contents.pdf`
2. any one `...bbb...pdf` from `data/raw/davis/zArchive/1970s/`
3. any one Davis file from before 1950
4. one Test and one ODI JSON from inside `data/raw/cricsheet/tests_json.zip` and `odis_json.zip`
5. one ESPN `..._BBB-COMMS.html` and one `..._PLYR-V-PLYR.html` from `data/raw/espn/`
6. one ESPN scorecard from the 1980s from `data/raw/espn/`
